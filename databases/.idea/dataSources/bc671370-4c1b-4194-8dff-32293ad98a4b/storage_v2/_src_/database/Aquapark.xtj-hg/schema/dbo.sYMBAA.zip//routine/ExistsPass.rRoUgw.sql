create procedure ExistsPass(@customer int, @service int, @time date)
AS select * from Passes p
where p.customer = @customer
and p.service = @service
and CONVERT(date, @time) = CONVERT(date, p.time);
go

